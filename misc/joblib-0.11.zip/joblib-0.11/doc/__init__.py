"""
This is a phony __init__.py file, so that pytest finds the doctests in this
directory.
"""
