joblib.hash
===========

.. currentmodule:: joblib

.. autofunction:: hash